﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ScrEntityToScrAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Scr, Models.Scr>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Lib, x => x.ResolveUsing<ScrLibResolver>())
                .ForMember(opt => opt.Par, x => x.ResolveUsing<ScrParResolver>());
        }
    }
}