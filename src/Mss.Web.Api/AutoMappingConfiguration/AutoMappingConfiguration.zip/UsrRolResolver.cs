﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Rol = Mss.Web.Api.Models.Rol;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrRolResolver : ValueResolver<Usr, List<Rol>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Rol> ResolveCore(Usr source)
        {
            return source.Rol.Select(x => AutoMapper.Map<Rol>(x)).ToList();
        }
    }
}