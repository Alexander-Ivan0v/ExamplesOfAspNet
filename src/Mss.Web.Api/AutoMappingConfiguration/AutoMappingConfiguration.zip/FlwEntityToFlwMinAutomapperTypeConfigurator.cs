﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class FlwEntityToFlwMinAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Flw, Models.FlwMin>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Tsk, x => x.ResolveUsing<FlwTskMinResolver>());
        }
    }
}