﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Team = Mss.Web.Api.Models.Team;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrTeamResolver : ValueResolver<Usr, List<Team>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Team> ResolveCore(Usr source)
        {
            return source.Team.Select(x => AutoMapper.Map<Team>(x)).ToList();
        }
    }
}