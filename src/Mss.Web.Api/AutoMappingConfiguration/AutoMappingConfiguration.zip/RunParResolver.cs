﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using ParWRunData = Mss.Web.Api.Models.ParWRunData;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunParResolver : ValueResolver<Run, List<ParWRunData>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<ParWRunData> ResolveCore(Run source)
        {
            return source.Par.Select(x => AutoMapper.Map<ParWRunData>(x)).ToList();
        }
    }
}