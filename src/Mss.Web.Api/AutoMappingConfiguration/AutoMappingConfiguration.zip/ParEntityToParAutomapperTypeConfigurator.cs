﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParEntityToParAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Par, Models.Par>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}