﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using ChgMin = Mss.Web.Api.Models.ChgMin;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunChgMinResolver : ValueResolver<Run, List<ChgMin>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<ChgMin> ResolveCore(Run source)
        {
            return source.Chg.Select(x => AutoMapper.Map<ChgMin>(x)).ToList();
        }
    }
}