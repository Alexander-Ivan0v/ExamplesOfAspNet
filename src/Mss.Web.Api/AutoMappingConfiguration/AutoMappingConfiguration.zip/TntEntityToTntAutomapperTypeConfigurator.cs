﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TntEntityToTntAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Tnt, Models.Tnt>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<TntChgResolver>())
                .ForMember(opt => opt.Srv, x => x.ResolveUsing<TntSrvResolver>());
        }
    }
}