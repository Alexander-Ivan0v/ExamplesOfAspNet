﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class FlwMinToFlwEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<FlwMin, Data.Entities.Flw>()
                .ForMember(opt => opt.IsDel, x => x.Ignore())
                .ForMember(opt => opt.IsDisabled, x => x.Ignore())
                .ForMember(opt => opt.IsSupport, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}