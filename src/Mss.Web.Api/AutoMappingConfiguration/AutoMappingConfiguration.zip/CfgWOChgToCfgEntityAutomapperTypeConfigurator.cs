﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class CfgWOChgToCfgEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<CfgWOChg, Data.Entities.Cfg>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.Ps, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.Ignore());
        }
    }
}