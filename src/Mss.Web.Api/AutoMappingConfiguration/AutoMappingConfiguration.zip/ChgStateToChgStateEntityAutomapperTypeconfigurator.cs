﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ChgStateToChgStateEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ChgState, Data.Entities.ChgState>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}