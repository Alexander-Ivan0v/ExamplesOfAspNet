﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using TskMin = Mss.Web.Api.Models.TskMin;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class FlwTskMinResolver : ValueResolver<Flw, List<TskMin>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<TskMin> ResolveCore(Flw source)
        {
            return source.Tsk.Select(x => AutoMapper.Map<TskMin>(x)).ToList();
        }
    }
}