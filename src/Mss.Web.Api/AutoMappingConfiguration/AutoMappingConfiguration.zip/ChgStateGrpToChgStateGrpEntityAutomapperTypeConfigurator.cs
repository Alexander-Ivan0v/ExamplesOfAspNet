﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ChgStateGrpToChgStateGrpEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ChgStateGrp, Data.Entities.ChgStateGrp>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}