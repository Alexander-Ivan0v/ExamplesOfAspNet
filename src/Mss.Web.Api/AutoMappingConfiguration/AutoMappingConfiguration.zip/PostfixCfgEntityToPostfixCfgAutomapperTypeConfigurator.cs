﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class PostfixCfgEntityToPostfixCfgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<PostfixCfg, Models.PostfixCfg>()
                .ForMember(opt => opt.Cat, x => x.ResolveUsing<PostfixCfgCatResolver>());
        }
    }
}