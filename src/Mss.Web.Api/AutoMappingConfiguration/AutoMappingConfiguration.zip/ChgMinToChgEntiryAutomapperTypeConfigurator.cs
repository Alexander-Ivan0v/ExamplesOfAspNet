﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ChgMinToChgEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ChgMin, Data.Entities.Chg>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.ChgLog, x => x.Ignore());
        }
    }
}