﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using PostfixCfg = Mss.Web.Api.Models.PostfixCfg;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SrvPostfixCfgResolver : ValueResolver<Srv, List<PostfixCfg>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<PostfixCfg> ResolveCore(Srv source)
        {
            return source.PostfixCfg.Select(x => AutoMapper.Map<PostfixCfg>(x)).ToList();
        }
    }
}