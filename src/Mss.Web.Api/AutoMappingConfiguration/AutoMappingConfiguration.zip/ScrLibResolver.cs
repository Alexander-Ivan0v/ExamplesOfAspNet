﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Tsk = Mss.Web.Api.Models.Tsk;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ScrLibResolver : ValueResolver<Scr, List<Lib>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Lib> ResolveCore(Scr source)
        {
            return source.Lib.Select(x => AutoMapper.Map<Lib>(x)).ToList();
        }
    }
}