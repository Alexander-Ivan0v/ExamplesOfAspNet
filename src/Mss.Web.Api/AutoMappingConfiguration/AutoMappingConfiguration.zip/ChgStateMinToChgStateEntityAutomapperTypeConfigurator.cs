﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ChgStateMinToChgStateEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ChgStateMin, Data.Entities.ChgState>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.ChgStateGrp, x => x.Ignore());
        }
    }
}