﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ClamavCfgEntityToClamavCfgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ClamavCfg, Models.ClamavCfg>()
                .ForMember(opt => opt.Cat, x => x.ResolveUsing<ClamavCfgCatResolver>());
        }
    }
}