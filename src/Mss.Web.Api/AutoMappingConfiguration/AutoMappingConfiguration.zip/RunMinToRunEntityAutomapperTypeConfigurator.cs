﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunMinToRunEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RunMin, Data.Entities.Run>()
                .ForMember(opt => opt.Par, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}