﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TskMinToTskEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<TskMin, Data.Entities.Tsk>()
                .ForMember(opt => opt.Action, x => x.Ignore())
                .ForMember(opt => opt.Rback, x => x.Ignore())
                .ForMember(opt => opt.IsDel, x => x.Ignore())
                .ForMember(opt => opt.IsDisabled, x => x.Ignore())
                .ForMember(opt => opt.IsLongRunning, x => x.Ignore())
                .ForMember(opt => opt.IsRollbackDisabled, x => x.Ignore())
                .ForMember(opt => opt.IsSupport, x => x.Ignore())
                .ForMember(opt => opt.Lib, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}