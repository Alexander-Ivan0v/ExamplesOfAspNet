﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities; 

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TeamEntityToTeamAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Team, Models.Team>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<TeamChgResolver>());
        }        
    }
}