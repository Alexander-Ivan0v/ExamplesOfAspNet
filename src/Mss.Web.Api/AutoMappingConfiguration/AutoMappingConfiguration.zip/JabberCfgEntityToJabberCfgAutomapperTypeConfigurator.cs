﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class JabberCfgEntityToJabberCfgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<JabberCfg, Models.JabberCfg>()
                .ForMember(opt => opt.Cat, x => x.ResolveUsing<JabberCfgCatResolver>());
        }
    }
}