﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class LibEntityToLibAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Lib, Models.Lib>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}