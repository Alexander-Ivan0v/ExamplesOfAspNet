﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SpamassasinCfgEntityToSpamassasinCfgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<SpamassasinCfg, Models.SpamassasinCfg>()
                .ForMember(opt => opt.Cat, x => x.ResolveUsing<SpamassasinCfgCatResolver>());
        }
    }
}