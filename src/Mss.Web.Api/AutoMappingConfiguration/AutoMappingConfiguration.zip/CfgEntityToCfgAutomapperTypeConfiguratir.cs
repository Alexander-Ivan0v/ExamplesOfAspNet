﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class CfgEntityToCfgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Cfg, Models.Cfg>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<CfgChgResolver>());
        }
    }
}