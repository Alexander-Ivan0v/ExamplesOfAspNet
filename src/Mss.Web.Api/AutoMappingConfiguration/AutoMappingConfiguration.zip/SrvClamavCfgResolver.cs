﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using ClamavCfg = Mss.Web.Api.Models.ClamavCfg;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SrvClamavCfgResolver : ValueResolver<Srv, List<ClamavCfg>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<ClamavCfg> ResolveCore(Srv source)
        {
            return source.ClamavCfg.Select(x => AutoMapper.Map<ClamavCfg>(x)).ToList();
        }
    }
}