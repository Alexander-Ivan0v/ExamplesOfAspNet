﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunDataToRunDataEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RunData, Data.Entities.RunData>()
                .ForMember(opt => opt.Run, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}