﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParEntityToParWRunDataAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Par, Models.ParWRunData>()
                .ForMember(opt => opt.RunData, x => x.Ignore())
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}