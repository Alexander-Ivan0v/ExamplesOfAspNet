﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunDataWOParToRunDataEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RunDataWOPar, Data.Entities.RunData>()
                .ForMember(opt => opt.Par, x => x.Ignore())
                .ForMember(opt => opt.Run, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}