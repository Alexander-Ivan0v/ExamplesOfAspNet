﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RolMinToRolEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RolMin, Data.Entities.Rol>()
                .ForMember(opt => opt.Tnt, x => x.Ignore())
                .ForMember(opt => opt.Cat, x => x.Ignore())
                .ForMember(opt => opt.IsDel, x => x.Ignore())
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}