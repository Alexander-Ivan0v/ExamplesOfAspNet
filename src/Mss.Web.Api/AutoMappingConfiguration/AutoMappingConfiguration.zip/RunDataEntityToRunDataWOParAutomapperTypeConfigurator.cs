﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunDataEntityToRunDataWOParAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RunData, Models.RunDataWOPar>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<RunDataChgResolver>());
        }
    }
}