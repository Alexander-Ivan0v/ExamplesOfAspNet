﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TeamOnlyToTeamEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<TeamOnly, Data.Entities.Team>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.Ignore());
        }
    }
}