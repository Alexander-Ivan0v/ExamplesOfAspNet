﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using JabberCfg = Mss.Web.Api.Models.JabberCfg;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SrvJabberCfgResolver : ValueResolver<Srv, List<JabberCfg>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<JabberCfg> ResolveCore(Srv source)
        {
            return source.JabberCfg.Select(x => AutoMapper.Map<JabberCfg>(x)).ToList();
        }
    }
}