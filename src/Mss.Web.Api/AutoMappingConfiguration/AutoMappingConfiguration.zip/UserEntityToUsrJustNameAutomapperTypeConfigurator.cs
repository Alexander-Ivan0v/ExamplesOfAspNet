﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrEntityToUsrJustNameAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Usr, Models.UsrJustName>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}