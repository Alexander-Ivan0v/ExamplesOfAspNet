﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParViewOptionEntityToParViewOptionAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ParViewOption, Models.ParViewOption>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}