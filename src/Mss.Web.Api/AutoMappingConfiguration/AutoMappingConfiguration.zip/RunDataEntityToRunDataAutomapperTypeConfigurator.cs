﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class RunDataEntityToRunDataAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<RunData, Models.RunData>()
                 .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<RunDataChgResolver>());
        }
    }
}