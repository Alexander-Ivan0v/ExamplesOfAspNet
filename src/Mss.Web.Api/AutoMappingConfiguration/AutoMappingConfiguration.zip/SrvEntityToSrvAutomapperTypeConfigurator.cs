﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SrvEntityToSrvAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Srv, Models.Srv>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Cat, x => x.ResolveUsing<SrvCatResolver>())
                .ForMember(opt => opt.PostfixCfg, x => x.ResolveUsing<SrvPostfixCfgResolver>())
                .ForMember(opt => opt.ClamavCfg, x => x.ResolveUsing<SrvClamavCfgResolver>())
                .ForMember(opt => opt.SpamassasinCfg, x => x.ResolveUsing<SrvSpamassasinCfgResolver>())
                .ForMember(opt => opt.JabberCfg, x => x.ResolveUsing<SrvJabberCfgResolver>());
        }
    }
}