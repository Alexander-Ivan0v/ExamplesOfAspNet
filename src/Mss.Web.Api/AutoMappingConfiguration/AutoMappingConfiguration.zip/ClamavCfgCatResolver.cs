﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Cat = Mss.Web.Api.Models.Cat;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ClamavCfgCatResolver : ValueResolver<ClamavCfg, List<Cat>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Cat> ResolveCore(ClamavCfg source)
        {
            return source.Cat.Select(x => AutoMapper.Map<Cat>(x)).ToList();
        }
    }
}