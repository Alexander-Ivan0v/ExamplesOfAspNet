﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrEntityToUsrAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Usr, Models.Usr>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Rol, x => x.ResolveUsing<UsrRolResolver>())
                .ForMember(opt => opt.Chg, x => x.ResolveUsing<UsrChgResolver>())
                .ForMember(opt => opt.Team, x => x.ResolveUsing<UsrTeamResolver>());
        }
    }
}