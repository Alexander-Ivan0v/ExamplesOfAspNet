﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrJustNameToUsrEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<UsrJustName, Data.Entities.Usr>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.Chg, x => x.Ignore())
                .ForMember(opt => opt.IsDel, x => x.Ignore())
                .ForMember(opt => opt.IsDisabled, x => x.Ignore())
                .ForMember(opt => opt.IsLocal, x => x.Ignore())
                .ForMember(opt => opt.Pass, x => x.Ignore())
                .ForMember(opt => opt.Rol, x => x.Ignore())
                .ForMember(opt => opt.Team, x => x.Ignore())
                .ForMember(opt => opt.Theme, x => x.Ignore())
                .ForMember(opt => opt.UDomain, x => x.Ignore())
                .ForMember(opt => opt.UEmail, x => x.Ignore())
                .ForMember(opt => opt.ULogin, x => x.Ignore());
        }
    }
}