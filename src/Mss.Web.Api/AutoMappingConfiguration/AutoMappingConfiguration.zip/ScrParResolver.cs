﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Par = Mss.Web.Api.Models.Par;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ScrParResolver : ValueResolver<Scr, List<Par>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Par> ResolveCore(Scr source)
        {
            return source.Par.Select(x => AutoMapper.Map<Par>(x)).ToList();
        }
    }
}