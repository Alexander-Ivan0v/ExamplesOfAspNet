﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Cat = Mss.Web.Api.Models.Cat;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class PostfixCfgCatResolver : ValueResolver<PostfixCfg, List<Cat>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Cat> ResolveCore(PostfixCfg source)
        {
            return source.Cat.Select(x => AutoMapper.Map<Cat>(x)).ToList();
        }
    }
}