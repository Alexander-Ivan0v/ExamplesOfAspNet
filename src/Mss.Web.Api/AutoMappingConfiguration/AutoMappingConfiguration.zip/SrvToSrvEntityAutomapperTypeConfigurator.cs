﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class SrvToSrvEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Srv, Data.Entities.Srv>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}