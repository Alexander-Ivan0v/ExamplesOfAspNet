﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using ParViewOption = Mss.Web.Api.Models.ParViewOption;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParViewParViewOptionResolver : ValueResolver<ParView, List<ParViewOption>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<ParViewOption> ResolveCore(ParView source)
        {
            return source.ParViewOption.Select(x => AutoMapper.Map<ParViewOption>(x)).ToList();
        }
    }
}