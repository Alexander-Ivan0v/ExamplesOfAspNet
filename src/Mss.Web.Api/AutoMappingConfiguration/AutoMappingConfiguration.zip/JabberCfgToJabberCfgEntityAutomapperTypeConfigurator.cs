﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class JabberCfgToJabberCfgEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<JabberCfg, Data.Entities.JabberCfg>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}