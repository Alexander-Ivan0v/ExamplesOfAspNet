﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class UsrNewToUsrEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<UsrNew, Data.Entities.Usr>()
                .ForMember(opt => opt.Version, x => x.Ignore())
                .ForMember(opt => opt.Rol, x => x.Ignore())
                .ForMember(opt => opt.Team, x => x.Ignore());
        }
    }
}