﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParSpecialEntityToParSpecialAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ParSpecial, Models.ParSpecial>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}