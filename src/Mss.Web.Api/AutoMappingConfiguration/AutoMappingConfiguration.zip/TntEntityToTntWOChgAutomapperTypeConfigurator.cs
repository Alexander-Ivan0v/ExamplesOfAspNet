﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TntEntityToTntWOChgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Tnt, Models.TntWOChg>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Srv, x => x.ResolveUsing<TntSrvResolver>());
        }
    }
}