﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class TeamEntityToTeamWOChgAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Team, Models.TeamWOChg>()
                .ForMember(opt => opt.Links, x => x.Ignore());
        }
    }
}