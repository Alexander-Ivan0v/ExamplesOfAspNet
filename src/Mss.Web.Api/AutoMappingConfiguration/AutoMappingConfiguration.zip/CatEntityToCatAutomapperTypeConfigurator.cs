﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class CatEntityToCatAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Cat, Models.Cat>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Tsk, x => x.ResolveUsing<CatTskResolver>())
                .ForMember(opt => opt.Flw, x => x.ResolveUsing<CatFlwResolver>());
        }
    }
}