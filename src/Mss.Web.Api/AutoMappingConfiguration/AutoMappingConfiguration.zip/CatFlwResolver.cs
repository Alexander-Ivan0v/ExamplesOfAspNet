﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Tsk = Mss.Web.Api.Models.Tsk;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class CatFlwResolver : ValueResolver<Cat, List<Flw>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Flw> ResolveCore(Cat source)
        {
            return source.Flw.Select(x => AutoMapper.Map<Flw>(x)).ToList();
        }
    }
}