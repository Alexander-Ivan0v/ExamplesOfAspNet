﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;
using Mss.Web.Common;
using Chg = Mss.Web.Api.Models.Chg;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class CfgChgResolver : ValueResolver<Cfg, List<Chg>>
    {
        public IAutoMapper AutoMapper
        {
            get { return WebContainerManager.Get<IAutoMapper>(); }
        }

        protected override List<Chg> ResolveCore(Cfg source)
        {
            return source.Chg.Select(x => AutoMapper.Map<Chg>(x)).ToList();
        }
    }
}