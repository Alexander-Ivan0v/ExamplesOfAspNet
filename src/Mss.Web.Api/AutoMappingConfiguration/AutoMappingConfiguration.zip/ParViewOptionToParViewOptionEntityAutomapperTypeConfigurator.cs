﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParViewOptionToParViewOptionEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ParViewOption, Data.Entities.ParViewOption>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}