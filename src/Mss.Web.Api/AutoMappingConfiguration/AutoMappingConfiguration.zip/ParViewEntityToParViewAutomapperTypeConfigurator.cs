﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class ParViewEntityToParViewAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<ParView, Models.ParView>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.ParViewOption, x => x.ResolveUsing<ParViewParViewOptionResolver>());
        }
    }
}