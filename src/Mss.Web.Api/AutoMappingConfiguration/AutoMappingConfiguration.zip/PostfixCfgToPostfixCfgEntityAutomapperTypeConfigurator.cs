﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Web.Api.Models;

namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class PostfixCfgToPostfixCfgEntityAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<PostfixCfg, Data.Entities.PostfixCfg>()
                .ForMember(opt => opt.Version, x => x.Ignore());
        }
    }
}