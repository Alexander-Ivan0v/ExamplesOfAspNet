﻿using AutoMapper;
using Mss.Common.TypeMapping;
using Mss.Data.Entities;


namespace Mss.Web.Api.AutoMappingConfiguration
{
    public class FlwEntityToFlwAutoMapperTypeConfigurator : IAutoMapperTypeConfigurator
    {
        public void Configure()
        {
            Mapper.CreateMap<Flw, Models.Flw>()
                .ForMember(opt => opt.Links, x => x.Ignore())
                .ForMember(opt => opt.Tsk, x => x.ResolveUsing<FlwTskResolver>());
        }
    }
}